<div class="col-lg">
    <div class="card p-3">
        <lottie-player src="https://assets7.lottiefiles.com/packages/lf20_dc8o2lwo.json" background="transparent"
            speed="1" loop autoplay></lottie-player>
    </div>
</div>
