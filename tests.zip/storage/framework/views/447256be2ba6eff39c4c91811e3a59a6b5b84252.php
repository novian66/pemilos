
<?php $__env->startSection('title'); ?>
    Homepage Siballu
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-xl">
            <div class="row row-card">
                <div class="col-sm-6 col-lg-8">
                    <div class="card p-2">
                        <div id="carousel-indicators" class="carousel slide" data-bs-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-bs-target="#carousel-indicators" data-bs-slide-to="0" class="active"></li>
                                <li data-bs-target="#carousel-indicators" data-bs-slide-to="1" class=""></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" alt=""
                                        src="https://images.tokopedia.net/img/cache/1208/NsjrJu/2022/8/12/462de4ea-4acb-4987-84e9-45a14794a72b.jpg.webp">
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" alt=""
                                        src="https://images.tokopedia.net/img/cache/1208/NsjrJu/2022/8/13/a2cdbfc5-51d7-4bd1-8f2d-ebf072caa882.jpg">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-lg-4">
                    <div class="card">
                        <div class="empty">
                            <p class="empty-title">Selamat Datang</p>
                            <p class="empty-subtitle text-muted">
                                Hai <strong class="text-danger"><?php echo e(auth()->user()->name); ?></strong> Apa Kabar ? Semoga Sehat
                                Selalu, Yuk Join Langsung Sesuai
                                Sekolah Kamu
                            </p>
                            <div class="empty-action">
                                <button type="button" class="btn btn-warning">
                                    <?php if(auth()->user()->getroleNames()[0] == 'student'): ?>
                                        Gabung Sekolah
                                    <?php elseif(auth()->user()->getroleNames()[0] == 'school'): ?>
                                        Kelola Sekolah
                                    <?php else: ?> 
                                        Kelola System
                                    <?php endif; ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\pemilos-kpu-banyumas\resources\views/home.blade.php ENDPATH**/ ?>