<?php $__env->startSection('title'); ?>
    List User <?php echo e($roles->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('button-header'); ?>
    <div class="btn-list">
        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary d-none d-sm-inline-block">
            <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24"
                stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
            New User
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-xl">
            <hr class="mt-0 mb-3">
            <div class="d-flex justify-content-between">
                <div>
                    <?php echo $user->links(); ?>

                </div>
                <form action="" method="GET">
                    <div class="row g-2">
                        <div class="col">
                            <input type="text" name="cari" class="form-control" placeholder="Cari Sekolah disini">
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-white btn-icon" aria-label="Button">
                                <!-- Download SVG icon from http://tabler-icons.io/i/search -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24"
                                    viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none"
                                    stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <circle cx="10" cy="10" r="7"></circle>
                                    <line x1="21" y1="21" x2="15" y2="15"></line>
                                </svg>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <hr class="mt-2 mb-0">
            <div class="row mt-3">
                <?php $__empty_1 = true; $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-3">
                        <div class="card mt-3">
                            <div class="card-body p-4 text-center">
                                <span class="avatar avatar-xl mb-3 avatar-rounded"
                                    style="background-image: url(<?php echo e(asset('dist/img/logo/')); ?>)"></span>
                                <h3 class="m-0 mb-1"><?php echo e($data->name); ?></h3>
                                <div class="text-muted"><?php echo e($data->email); ?></div>
                                <div class="mt-3">
                                    <span class="badge bg-purple-lt"><?php echo e($data->status); ?></span>
                                </div>
                            </div>
                            <div class="d-flex mt-1 mb-0">
                                <a class="card-btn text-danger cursor-pointer"
                                    onclick="event.preventDefault(); document.getElementById('hapus-election-<?php echo e($data->id); ?>').submit();">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon me-2 text-danger" width="24"
                                        height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                        fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                        <line x1="4" y1="7" x2="20" y2="7"></line>
                                        <line x1="10" y1="11" x2="10" y2="17"></line>
                                        <line x1="14" y1="11" x2="14" y2="17"></line>
                                        <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"></path>
                                        <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"></path>
                                    </svg>
                                    Delete
                                </a>
                                <form id="hapus-election-<?php echo e($data->id); ?>"
                                    action="<?php echo e(route('users.delete', $data->id)); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                </form>
                            </div>
                        </div>
                    </div>

                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php echo $__env->make('layouts.theme.empty', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\pemilos-kpu-banyumas\resources\views/admin/user/list.blade.php ENDPATH**/ ?>