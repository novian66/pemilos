
<?php $__env->startSection('title'); ?>
    User Management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-body">
        <div class="container-xl">
            <div class="row row-card">
                <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card mt-3">
                            <div class="card-body">
                                <h3 class="card-title"><?php echo e($user->name); ?></h3>
                                <p>
                                    Kelola User kamu disini, mulai dari Create Read Update dan Delete User
                                </p>
                            </div>
                            <!-- Card footer -->
                            <div class="card-footer text-center">
                                <a href="<?php echo e(route('users.list', $user->name)); ?>" class="btn btn-link">List Users</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\pemilos-kpu-banyumas\resources\views/admin/user/index.blade.php ENDPATH**/ ?>